
OriRisk AI - Backend + Training Scaffold
----------------------------------------
Upload this folder to Replit.
Insert the full backend FastAPI code into main.py.
Insert the training pipeline code into train_oririsk_individus.py.
Install dependencies via requirements.txt.
